<script setup>
import Summary from '../components/Summary.vue';
</script>

<template>
  <main>
    <Summary />
  </main>
</template>
